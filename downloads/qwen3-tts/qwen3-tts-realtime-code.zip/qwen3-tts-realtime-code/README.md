# Qwen3-TTS 实时播放优化：核心代码快照

配套文章：Qwen3-TTS 本地 GPU 实践：从实时播放卡顿到 CUDA Graph 加速。
快照日期：2026-11-05；文中 Windows 性能数据来自 2026-11-04 的实际测试记录。

这不是包含模型和 CUDA 驱动的离线安装包。代码需要 NVIDIA CUDA GPU、完整模型目录及对应依赖；不提供 CPU 推理回退。正文是原理与节选，本目录包含完整的服务和前端实现。

## 已验证的版本与范围

- Python 3.12；Windows 下 PyTorch 2.10.0+cu128；Transformers 4.57.3。
- Qwen3-TTS 0.1.1，对照上游提交 022e286b98fbec7e1e916cb940cdf532cd9f488e 的内部编码接口。
- RTX 5070 Ti 16 GB，BF16，SDPA，单个生成任务。
- 默认 1.7B CustomVoice；可选 0.6B CustomVoice，不支持语气指令。
- requirements-snapshot.txt 是运行依赖锁定快照；跨平台安装时仍需检查平台 wheel 与 Python 版本支持情况。

## Windows 启动示例（在本目录中执行）

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch==2.10.0 torchaudio==2.10.0 --index-url https://download.pytorch.org/whl/cu128
.\.venv\Scripts\python.exe -m pip install -r requirements-snapshot.txt
$env:TTS_MODEL_PATH=(Resolve-Path '.\models\Qwen3-TTS-12Hz-1.7B-CustomVoice').Path
$env:TTS_OUTPUT_DIR=Join-Path $PWD 'audio'
$env:TTS_ENABLE_FAST_MODEL='0'
$env:TTS_CUDA_GRAPH='1'
$env:TTS_CPU_THREADS='4'
$env:TTS_DEVICE='cuda:0'
$env:TTS_HOST='127.0.0.1'
$env:TTS_PORT='7860'
.\.venv\Scripts\python.exe run-fast.py
```

先从官方模型页下载完整目录，保留 config、文本 tokenizer、权重以及 speech_tokenizer/ 子目录。权重可以是单文件，也可以是带 index JSON 的完整分片。上例的 models/ 路径只是示例，必须先准备模型，不能对不存在的目录执行 Resolve-Path。

要启用 0.6B，另设 TTS_FAST_MODEL_PATH 并将 TTS_ENABLE_FAST_MODEL 设为 1。它是可选模型，加载失败时保留主模型服务。

Linux 同样通过 TTS_MODEL_PATH、TTS_OUTPUT_DIR 等环境变量配置，并按其 CUDA/PyTorch 环境安装依赖；本文未把 Windows 实测速度直接套用于 Linux。

## 加载兼容与图重放

TTS_BUFFERED_WEIGHTS=1 使用 checkpoint_reader.py 的逐张量读取，并跳过 Transformers 的大块预分配。这是本次权重加载兼容措施，依赖内部接口，只加载可信本地权重。原生加载正常时可设 TTS_BUFFERED_WEIGHTS=0。

TTS_CUDA_GRAPH=0 关闭图重放。启用时先检查贪心等价性和随机状态推进；捕获失败回退已验证的固定步数预测。采样参数或形状不匹配时使用普通固定循环。多 GPU、不同 dtype、不同批量与升级依赖需要额外适配和验证，不能把当前实现当作所有场景通用的 generate 替代品。

## 接口

- GET /api/status：模型、设备、图重放状态和最近统计。
- POST /api/tts：完整 WAV 地址和统计。
- POST /api/tts/wav：直接返回完整 WAV。
- POST /api/tts/stream：NDJSON；audio 事件包含 PCM16 little-endian、采样率和编号，done 包含完整音频地址，error 明确失败。
- GET /docs：本地静态资源支持的接口文档。

示例请求：

```json
{"text":"你好，欢迎使用本地语音合成服务。","language":"Chinese","speaker":"Serena","model":"quality","chunk_frames":12}
```

quality 对应 1.7B，fast 对应可选的 0.6B。并发生成被串行限制，忙碌返回 429。前端以 AbortController 和本轮编号处理取消，后端用取消标记及锁清理任务。

默认本机访问；不要仅通过开放绑定地址就把未经认证的接口暴露到公网。CORS 不提供身份认证。

## 验证

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

上述是 FakeEngine 的接口契约测试，不能代替真实 GPU 生成、CUDA Graph 检查、长文本和多语言试听。代码快照里的默认演示文案已经通用化；配套文章的数据引用原始测试记录，改动示例文案后不应期望得到同样的音频长度。

## 来源与许可说明

- 上游项目：https://github.com/QwenLM/Qwen3-TTS
- Qwen3-TTS 的上游许可说明保存在 UPSTREAM-LICENSE.txt。
- static/docs/ 中的 Swagger UI 保留其 LICENSE.swagger-ui 与 UPSTREAM.txt。
- PyTorch、Transformers、Gradio 等依赖遵循各自的许可。

本包未包含模型权重、运行日志、音频内容、API Key 或本机私有配置。
