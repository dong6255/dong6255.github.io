"""Memory-conscious checkpoint reads without whole-shard GPU mappings."""
import json
import struct
import torch
import transformers.modeling_utils as modeling_utils

class TensorSlice:
    def __init__(self, reader, name):
        self.reader, self.name = reader, name
    def get_shape(self):
        return self.reader.header[self.name]['shape']
    def get_dtype(self):
        return self.reader.header[self.name]['dtype']
    def __getitem__(self, key):
        return self.reader.get_tensor(self.name)[key]

class BufferedSafeOpen:
    def __init__(self, filename, framework='pt', device='cpu'):
        self.filename = filename
        self.device = f'cuda:{device}' if isinstance(device, int) else device
        with open(filename, 'rb') as inp:
            length = struct.unpack('<Q', inp.read(8))[0]
            self.header = json.loads(inp.read(length))
            self.base = 8 + length
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def metadata(self):
        return self.header.get('__metadata__')
    def keys(self):
        return [name for name in self.header if name != '__metadata__']
    def get_slice(self, name):
        return TensorSlice(self, name)
    def get_tensor(self, name):
        info = self.header[name]
        start, end = info['data_offsets']
        with open(self.filename, 'rb') as inp:
            inp.seek(self.base + start)
            data = bytearray(inp.read(end - start))
        if len(data) != end - start:
            raise OSError(f'Truncated tensor: {name}')
        dtype = modeling_utils.str_to_torch_dtype[info['dtype']]
        tensor = torch.frombuffer(data, dtype=dtype).reshape(info['shape'])
        return tensor.to(self.device)

# Keep startup peaks bounded on both Windows and Linux/WSL.
modeling_utils.safe_open = BufferedSafeOpen
modeling_utils.caching_allocator_warmup = lambda *args, **kwargs: None

