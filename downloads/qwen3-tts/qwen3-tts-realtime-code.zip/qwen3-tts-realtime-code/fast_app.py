"""Local PCM streaming service; no external encoder or cloud calls required."""
import asyncio
import base64
import json
import io
import re
import threading
import uuid
from pathlib import Path

import gradio as gr
import numpy as np
import soundfile as sf
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from service_config import load_settings

ROOT = Path(__file__).resolve().parent
OUTPUT = load_settings().output_dir
OUTPUT.mkdir(parents=True, exist_ok=True)


class SpeechRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)
    language: str = 'Chinese'
    speaker: str = 'Serena'
    instruct: str = Field(default='', max_length=300)
    chunk_frames: int = Field(default=12, ge=6, le=36)
    seed: int | None = None
    model: str = 'quality'


def create_app(engine, fast_engine=None):
    app = FastAPI(title='Qwen3-TTS Intranet API', version='1.0.0', docs_url=None, redoc_url=None,
                  description='Local CUDA speech generation; weights supplied as read-only mounts.')
    origins = load_settings().cors_origins
    if origins:
        app.add_middleware(CORSMiddleware, allow_origins=list(origins),
                           allow_methods=['GET', 'POST'], allow_headers=['Content-Type', 'Authorization'],
                           expose_headers=['X-Sample-Rate', 'X-Audio-Duration', 'X-Generation-Seconds'])
    docs_path = ROOT / 'static' / 'docs'
    app.mount('/static/docs', StaticFiles(directory=docs_path), name='offline-docs')

    @app.get('/docs', include_in_schema=False)
    def api_docs():
        return get_swagger_ui_html(
            openapi_url='/openapi.json', title=app.title,
            swagger_js_url='/static/docs/swagger-ui-bundle.js',
            swagger_css_url='/static/docs/swagger-ui.css',
            swagger_favicon_url='data:,',
            swagger_ui_parameters={'validatorUrl': None},
        )
    gate = asyncio.Semaphore(1)
    engines = {'quality': engine}
    if fast_engine is not None:
        engines['fast'] = fast_engine
        fast_engine.lock = engine.lock

    def validate(data):
        if data.model not in engines:
            raise HTTPException(422, '所选模型暂不可用。')
        selected = engines[data.model]
        if data.model == 'fast' and data.instruct.strip():
            raise HTTPException(422, '快速模型不支持语气指令，请使用高品质模型。')
        if not data.text.strip():
            raise HTTPException(422, '请输入需要朗读的文字。')
        if data.language.lower() not in {s.lower() for s in selected.tts.get_supported_languages()}:
            raise HTTPException(422, '不支持所选语言。')
        if data.speaker.lower() not in {s.lower() for s in selected.tts.get_supported_speakers()}:
            raise HTTPException(422, '不支持所选音色。')
        return selected

    def save(audio, sr):
        name = uuid.uuid4().hex + '.wav'
        sf.write(OUTPUT / name, audio, sr, subtype='PCM_16')
        return '/audio/' + name

    @app.get('/')
    def home():
        return FileResponse(ROOT / 'streaming.html')

    @app.get('/api/status')
    def status():
        return {**engine.diagnostics, 'busy': engine.lock.locked(), 'last_profile': engine.last_profile,
                'models': {key: value.diagnostics for key, value in engines.items()}}

    @app.get('/healthz')
    def health():
        return {'status': 'ok', 'models': list(engines), 'device': engine.diagnostics['model_device']}

    @app.get('/audio/{name}')
    def audio_file(name: str):
        if not re.fullmatch(r'[0-9a-f]{32}\.wav', name) or not (OUTPUT / name).is_file():
            raise HTTPException(404)
        return FileResponse(OUTPUT / name, media_type='audio/wav', filename=name)

    @app.post('/api/tts')
    async def full(data: SpeechRequest):
        selected = validate(data)
        if gate.locked() or engine.lock.locked():
            raise HTTPException(429, '正在生成另一段语音，请稍后重试。')
        async with gate:
            audio, sr, profile = await asyncio.to_thread(
                selected.full, data.text, data.language, data.speaker, data.instruct, data.seed)
            return {'audio_url': save(audio, sr), 'sample_rate': sr, 'profile': profile}

    @app.post('/api/tts/wav', response_class=Response,
              responses={200: {'content': {'audio/wav': {}}}})
    async def wav(data: SpeechRequest):
        selected = validate(data)
        if gate.locked() or engine.lock.locked():
            raise HTTPException(429, '正在生成另一段语音，请稍后重试。')
        async with gate:
            audio, sr, profile = await asyncio.to_thread(
                selected.full, data.text, data.language, data.speaker, data.instruct, data.seed)
            buffer = io.BytesIO()
            sf.write(buffer, audio, sr, format='WAV', subtype='PCM_16')
            return Response(buffer.getvalue(), media_type='audio/wav', headers={
                'Content-Disposition': 'attachment; filename="speech.wav"',
                'X-Sample-Rate': str(sr),
                'X-Audio-Duration': str(profile['audio_seconds']),
                'X-Generation-Seconds': str(profile['total_seconds']),
            })

    @app.post('/api/tts/stream', response_class=StreamingResponse,
              responses={200: {'description': 'Newline-delimited JSON: audio chunks, then done or error.',
                               'content': {'application/x-ndjson': {'schema': {'type': 'string'}}}}})
    async def stream(data: SpeechRequest):
        selected = validate(data)
        if gate.locked() or engine.lock.locked():
            raise HTTPException(429, '正在生成另一段语音，请稍后重试。')
        await gate.acquire()
        cancel = threading.Event()
        iterator = selected.stream(data.text, data.language, data.speaker, data.instruct,
                                 data.chunk_frames, cancel, data.seed)

        def next_event():
            return next(iterator, None)

        async def events():
            index = 0
            try:
                while True:
                    event = await asyncio.to_thread(next_event)
                    if event is None:
                        return
                    if event['event'] == 'audio':
                        pcm = (np.clip(event.pop('audio'), -1, 1) * 32767).astype('<i2')
                        event['pcm'] = base64.b64encode(pcm.tobytes()).decode('ascii')
                        event.update(format='pcm_s16le', channels=1, index=index)
                        index += 1
                    elif event['event'] == 'done':
                        event['audio_url'] = save(event.pop('audio'), event['sample_rate'])
                    yield json.dumps(event, ensure_ascii=False) + '\n'
            finally:
                cancel.set()
                gate.release()
                try:
                    iterator.close()
                except ValueError:
                    pass  # Pending next_event exits after observing cancel.

        return StreamingResponse(events(), media_type='application/x-ndjson',
                                 headers={'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no'})

    class LegacyAdapter:
        def __getattr__(self, name):
            return getattr(engine.tts, name)

        def generate_custom_voice(self, text, language, speaker, instruct=None, **kwargs):
            audio, sr, _ = engine.full(text, language, speaker, instruct or '')
            return [audio], sr

    if load_settings().legacy_ui:
        from qwen_tts.cli.demo import build_demo
        legacy = build_demo(LegacyAdapter(), str(engine.diagnostics['model']), {})
        legacy.queue(default_concurrency_limit=1, max_size=8)
        return gr.mount_gradio_app(app, legacy, path='/legacy')
    return app
