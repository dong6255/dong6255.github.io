"""Incremental audio generation and measured, reversible inference optimizations."""
import json
import queue
import threading
import time
import types
from pathlib import Path

import numpy as np
import torch
from qwen_tts import Qwen3TTSModel
from service_config import load_settings, validate_model

MODEL = str(load_settings().model_path)


def fixed_codebook_generate(predictor, *, inputs_embeds, max_new_tokens,
                            do_sample=True, top_k=50, top_p=1.0, temperature=0.9,
                            **kwargs):
    """Same fixed-length codebook decoding without HF's per-step stop machinery.

    This predictor has no EOS token. Preserve temperature/top-k/top-p sampling.
    The main speech model keeps the original Hugging Face generation loop.
    """
    tokens, cache, previous = [], None, None
    for step in range(max_new_tokens):
        output = predictor(
            inputs_embeds=inputs_embeds if step == 0 else None,
            input_ids=previous,
            past_key_values=cache,
            generation_steps=step,
            use_cache=True,
            output_hidden_states=False,
            return_dict=True,
        )
        cache = output.past_key_values
        logits = output.logits[:, -1, :].float()
        if do_sample:
            logits = logits / temperature
            if top_k:
                cutoff = torch.topk(logits, min(top_k, logits.shape[-1]), dim=-1).values[:, -1:]
                logits = logits.masked_fill(logits < cutoff, -float('inf'))
            if top_p < 1:
                values, indices = torch.sort(logits, descending=False)
                remove = values.softmax(-1).cumsum(-1) <= (1 - top_p)
                remove[:, -1] = False
                logits = logits.masked_fill(torch.zeros_like(remove).scatter(1, indices, remove), -float('inf'))
            previous = torch.multinomial(logits.softmax(-1), 1)
        else:
            previous = logits.argmax(-1, keepdim=True)
        tokens.append(previous)
    return types.SimpleNamespace(sequences=torch.cat(tokens, dim=-1))


class Cancelled(Exception):
    pass


class Engine:
    def __init__(self, model_path=MODEL):
        settings = load_settings()
        validate_model(model_path)
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA GPU unavailable. Start the container with --gpus and NVIDIA Container Toolkit.')
        self.device = torch.device(settings.device)
        torch.cuda.set_device(self.device)
        self.original_threads = torch.get_num_threads()
        torch.set_num_threads(settings.threads)
        if torch.get_num_interop_threads() != 1:
            torch.set_num_interop_threads(1)
        self.tts = Qwen3TTSModel.from_pretrained(
            str(model_path), device_map=str(self.device), dtype=torch.bfloat16,
            attn_implementation='sdpa', local_files_only=True,
        )
        self.lock = threading.Lock()
        self.predictor = self.tts.model.talker.code_predictor
        self.original_predictor = self.predictor.generate
        self.fast_predictor = types.MethodType(fixed_codebook_generate, self.predictor)
        self.stats = {}
        self.last_profile = {}
        self.samples_per_frame = self.tts.model.speech_tokenizer.get_decode_upsample_rate()
        original_generate = self.tts.model.generate
        original_decode = self.tts.model.speech_tokenizer.decode

        def timed_generate(*args, **kwargs):
            torch.cuda.synchronize()
            start = time.perf_counter()
            result = original_generate(*args, **kwargs)
            limit = kwargs.get('max_new_tokens', 4096)
            if any(code.shape[0] >= limit - 1 for code in result[0]):
                raise RuntimeError('生成长度达到上限，请将文字拆成较短的段落后重试。')
            torch.cuda.synchronize()
            self.stats['generation_seconds'] = time.perf_counter() - start
            return result

        def timed_decode(*args, **kwargs):
            torch.cuda.synchronize()
            start = time.perf_counter()
            result = original_decode(*args, **kwargs)
            self.stats['decode_seconds'] = self.stats.get('decode_seconds', 0) + time.perf_counter() - start
            return result

        self.tts.model.generate = timed_generate
        self.tts.model.speech_tokenizer.decode = timed_decode
        self.verify_predictor()
        self.predictor.generate = self.fast_predictor
        self.diagnostics = {
            'gpu': torch.cuda.get_device_name(self.device),
            'model': str(model_path), 'torch': torch.__version__, 'cuda': torch.version.cuda,
            'threads': torch.get_num_threads(),
            'attention': self.tts.model.talker.config._attn_implementation,
            'model_device': str(next(self.tts.model.talker.parameters()).device),
            'decoder_device': str(next(self.tts.model.speech_tokenizer.model.parameters()).device),
            'fast_predictor_verified': True,
            'weight_loader': 'buffered' if settings.buffered_weights else 'native',
        }
        print('RUNTIME', json.dumps(self.diagnostics), flush=True)

    def verify_predictor(self):
        p = self.predictor
        width = self.tts.model.config.talker_config.hidden_size
        for seed in (11, 29):
            torch.manual_seed(seed)
            embeddings = torch.randn(1, 2, width, device=self.device, dtype=torch.bfloat16)
            with torch.inference_mode():
                expected = self.original_predictor(
                    inputs_embeds=embeddings, max_new_tokens=15, do_sample=False,
                    return_dict_in_generate=True, output_hidden_states=False,
                ).sequences
                actual = self.fast_predictor(
                    inputs_embeds=embeddings, max_new_tokens=15, do_sample=False,
                ).sequences
            if not torch.equal(expected, actual):
                raise RuntimeError('Fixed codebook decoder failed greedy equivalence check')
        print('PREDICTOR: original and optimized greedy outputs match (2 inputs)', flush=True)

    def _generate(self, text, language, speaker, instruct, seed=None):
        if seed is not None:
            torch.manual_seed(seed)
        return self.tts.generate_custom_voice(
            text=text, language=language, speaker=speaker, instruct=instruct or None,
            max_new_tokens=4096,
        )

    def full(self, text, language='Chinese', speaker='Serena', instruct='', seed=None):
        with self.lock, torch.cuda.device(self.device), torch.inference_mode():
            self.stats = {}
            start = time.perf_counter()
            waves, sr = self._generate(text, language, speaker, instruct, seed)
            elapsed = time.perf_counter() - start
            profile = {**self.stats, 'total_seconds': elapsed,
                       'audio_seconds': len(waves[0]) / sr}
            profile['rtf'] = elapsed / profile['audio_seconds']
            self.last_profile = profile
            return waves[0], sr, profile

    def stream(self, text, language='Chinese', speaker='Serena', instruct='',
               chunk_frames=12, cancel=None, seed=None):
        """Emit causal codec chunks while the main model is still generating."""
        cancel = cancel or threading.Event()
        messages = queue.Queue(maxsize=4)

        def send(event):
            while not cancel.is_set():
                try:
                    messages.put(event, timeout=0.1)
                    return
                except queue.Full:
                    pass
            raise Cancelled()

        def worker():
            try:
                with self.lock, torch.cuda.device(self.device), torch.inference_mode():
                    self.stats = {}
                    started = time.perf_counter()
                    frames, emitted, first_audio = [], 0, None
                    chunks = []

                    def emit():
                        nonlocal emitted, first_audio
                        if len(frames) == emitted:
                            return
                        left = max(0, emitted - 25)
                        codes = torch.stack(frames[left:], dim=0)
                        waves, sr = self.tts.model.speech_tokenizer.decode([{'audio_codes': codes}])
                        audio = waves[0][(emitted - left) * self.samples_per_frame:]
                        emitted = len(frames)
                        if audio.size:
                            first_audio = first_audio or (time.perf_counter() - started)
                            chunks.append(audio)
                            send({'event': 'audio', 'audio': audio, 'sample_rate': sr,
                                  'first_audio_seconds': first_audio})

                    def capture(module, args, output):
                        if cancel.is_set():
                            raise Cancelled()
                        codes = output.hidden_states[-1]
                        if codes is None:
                            return
                        if int(codes[0, 0]) == self.tts.model.config.talker_config.codec_eos_token_id:
                            return
                        frames.append(codes[0].detach())
                        if len(frames) - emitted >= chunk_frames:
                            emit()

                    handle = self.tts.model.talker.register_forward_hook(capture)
                    try:
                        waves, sr = self._generate(text, language, speaker, instruct, seed)
                        emit()
                    finally:
                        handle.remove()
                    elapsed = time.perf_counter() - started
                    profile = {**self.stats, 'total_seconds': elapsed,
                               'audio_seconds': len(waves[0]) / sr,
                               'first_audio_seconds': first_audio, 'chunks': len(chunks)}
                    profile['rtf'] = elapsed / profile['audio_seconds']
                    combined = np.concatenate(chunks) if chunks else np.array([], dtype=np.float32)
                    profile['stream_samples'] = len(combined)
                    profile['full_samples'] = len(waves[0])
                    if len(combined) != len(waves[0]):
                        raise RuntimeError('Stream and final audio lengths differ')
                    profile['stream_full_rmse'] = float(np.sqrt(np.mean((combined - waves[0]) ** 2)))
                    self.last_profile = profile
                    send({'event': 'done', 'audio': waves[0], 'sample_rate': sr, 'profile': profile})
            except Cancelled:
                pass
            except Exception as exc:
                try:
                    send({'event': 'error', 'message': str(exc)})
                except Cancelled:
                    pass

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        try:
            while True:
                if cancel.is_set():
                    return
                try:
                    event = messages.get(timeout=0.2)
                except queue.Empty:
                    if not thread.is_alive():
                        return
                    continue
                yield event
                if event['event'] in ('done', 'error'):
                    return
        finally:
            cancel.set()
            thread.join(timeout=10)

    def benchmark(self, output):
        text = '你好，欢迎使用本地语音合成服务，很高兴为您服务。'
        self.full('你好。', seed=42)
        rows = []
        for name, threads, fast in [('original', self.original_threads, False),
                                    ('threads4', 4, False), ('fast4', 4, True), ('fast1', 1, True)]:
            torch.set_num_threads(threads)
            self.predictor.generate = self.fast_predictor if fast else self.original_predictor
            _, _, profile = self.full(text, instruct='用自然、清晰、亲切的语气说话。', seed=42)
            row = {'variant': name, 'threads': threads, **profile}
            rows.append(row)
            print('BENCHMARK', json.dumps(row), flush=True)
        best = min((r for r in rows if r['variant'].startswith('fast')), key=lambda r: r['rtf'])
        torch.set_num_threads(best['threads'])
        self.predictor.generate = self.fast_predictor
        for event in self.stream(text, instruct='用自然、清晰、亲切的语气说话。', seed=42):
            if event['event'] == 'error':
                raise RuntimeError(event['message'])
            if event['event'] == 'done':
                rows.append({'variant': 'stream', 'threads': best['threads'], **event['profile']})
                print('STREAM BENCHMARK', json.dumps(rows[-1]), flush=True)
        Path(output).write_text(json.dumps(rows, indent=2), encoding='utf-8')
        return rows
