"""CUDA graph for the fixed-shape, 15-step audio codebook predictor."""
import types
import torch
from fast_engine import fixed_codebook_generate


class GraphPredictor:
    def __init__(self, predictor, width, *, sample=True):
        self.predictor = predictor
        self.sample = sample
        self.static_input = torch.zeros(1, 2, width, device=next(predictor.parameters()).device, dtype=torch.bfloat16)
        self.graph = torch.cuda.CUDAGraph()
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream), torch.inference_mode():
            for _ in range(3):
                fixed_codebook_generate(predictor, inputs_embeds=self.static_input,
                                        max_new_tokens=15, do_sample=sample)
        stream.synchronize()
        with torch.inference_mode(), torch.cuda.graph(self.graph, stream=stream):
            self.static_output = fixed_codebook_generate(
                predictor, inputs_embeds=self.static_input,
                max_new_tokens=15, do_sample=sample,
            ).sequences
        torch.cuda.current_stream().wait_stream(stream)

    def __call__(self, *, inputs_embeds, max_new_tokens, do_sample=True,
                 top_k=50, top_p=1.0, temperature=0.9, **kwargs):
        if (inputs_embeds.shape != self.static_input.shape or max_new_tokens != 15
                or do_sample != self.sample or top_k != 50 or top_p != 1.0 or temperature != 0.9):
            return fixed_codebook_generate(
                self.predictor, inputs_embeds=inputs_embeds, max_new_tokens=max_new_tokens,
                do_sample=do_sample, top_k=top_k, top_p=top_p, temperature=temperature, **kwargs)
        self.static_input.copy_(inputs_embeds)
        self.graph.replay()
        return types.SimpleNamespace(sequences=self.static_output.clone())


def install(engine):
    predictor = engine.predictor
    width = engine.tts.model.config.talker_config.hidden_size
    # Validate replay against the eager decoder before enabling sampling.
    greedy = GraphPredictor(predictor, width, sample=False)
    with torch.inference_mode():
        for seed in (11, 29):
            torch.manual_seed(seed)
            data = torch.randn(1, 2, width, device=engine.device, dtype=torch.bfloat16)
            expected = engine.fast_predictor(inputs_embeds=data, max_new_tokens=15, do_sample=False).sequences
            actual = greedy(inputs_embeds=data, max_new_tokens=15, do_sample=False).sequences
            if not torch.equal(expected, actual):
                raise RuntimeError('CUDA graph greedy equivalence check failed')
    del greedy
    sampled = GraphPredictor(predictor, width, sample=True)
    # Captured CUDA RNG must advance rather than replaying the same noise.
    with torch.inference_mode():
        first = sampled(inputs_embeds=data, max_new_tokens=15).sequences
        second = sampled(inputs_embeds=data, max_new_tokens=15).sequences
        if torch.equal(first, second):
            raise RuntimeError('CUDA graph random state did not advance')
    predictor.generate = sampled
    engine.diagnostics['cuda_graph'] = True
    print('CUDA GRAPH: greedy equivalence and RNG advancement verified', flush=True)
    return sampled
