"""Single-process GPU service; model weights are always read from local directories."""
import os

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
os.environ.setdefault('GRADIO_ANALYTICS_ENABLED', 'False')
from service_config import load_settings
if load_settings().buffered_weights:
    import checkpoint_reader

import torch
import uvicorn
from fast_engine import Engine
from fast_app import create_app
from graph_predictor import install as install_graph


def accelerate(instance, settings):
    instance.diagnostics['cuda_graph'] = False
    if not settings.cuda_graph:
        return
    try:
        install_graph(instance)
    except Exception as exc:
        print('CUDA graph unavailable; using verified eager predictor:', repr(exc), flush=True)


def main():
    settings = load_settings()
    engine = Engine(str(settings.model_path))
    accelerate(engine, settings)
    engine.full('你好。', seed=42)
    small_engine = None
    if settings.fast_model:
        try:
            small_engine = Engine(str(settings.fast_model_path))
            accelerate(small_engine, settings)
            small_engine.full('你好。', seed=42)
        except Exception as exc:
            small_engine = None
            engine.diagnostics['optional_model_error'] = str(exc)
            import gc
            gc.collect()
            torch.cuda.empty_cache()
            print('Optional 0.6B model unavailable; continuing with 1.7B:', repr(exc), flush=True)
    for instance in (engine, small_engine):
        if instance is not None:
            for event in instance.stream('你好，很高兴为您服务。'):
                if event['event'] == 'error':
                    raise RuntimeError(event['message'])
    print('WARMUP COMPLETE', flush=True)
    uvicorn.run(create_app(engine, small_engine), host=settings.host, port=settings.port,
                log_level='info', timeout_graceful_shutdown=20)


if __name__ == '__main__':
    main()
