"""Portable configuration for native Windows and offline Linux containers."""
import json
import os
from dataclasses import dataclass
from pathlib import Path


def boolean(name, default):
    value = os.getenv(name, str(int(default))).strip().lower()
    if value not in {'1', '0', 'true', 'false', 'yes', 'no', 'on', 'off'}:
        raise ValueError(f'{name} must be 1 or 0')
    return value in {'1', 'true', 'yes', 'on'}


@dataclass(frozen=True)
class Settings:
    model_path: Path
    fast_model_path: Path
    output_dir: Path
    host: str
    port: int
    threads: int
    device: str
    cuda_graph: bool
    fast_model: bool
    legacy_ui: bool
    cors_origins: tuple[str, ...]
    buffered_weights: bool


def load_settings():
    native = os.name == 'nt'
    root = str(Path('models').resolve())
    output = str(Path('audio').resolve())
    settings = Settings(
        model_path=Path(os.getenv('TTS_MODEL_PATH', f'{root}/Qwen3-TTS-12Hz-1.7B-CustomVoice')),
        fast_model_path=Path(os.getenv('TTS_FAST_MODEL_PATH', f'{root}/Qwen3-TTS-12Hz-0.6B-CustomVoice')),
        output_dir=Path(os.getenv('TTS_OUTPUT_DIR', output)),
        host=os.getenv('TTS_HOST', '127.0.0.1'),
        port=int(os.getenv('TTS_PORT', '7860')),
        threads=int(os.getenv('TTS_CPU_THREADS', '4')),
        device=os.getenv('TTS_DEVICE', 'cuda:0'),
        cuda_graph=boolean('TTS_CUDA_GRAPH', True),
        fast_model=boolean('TTS_ENABLE_FAST_MODEL', native),
        legacy_ui=boolean('TTS_ENABLE_LEGACY_UI', True),
        cors_origins=tuple(s.strip() for s in os.getenv('TTS_CORS_ORIGINS', '').split(',') if s.strip()),
        buffered_weights=boolean('TTS_BUFFERED_WEIGHTS', True),
    )
    if not 1 <= settings.port <= 65535 or settings.threads < 1:
        raise ValueError('Invalid TTS_PORT or TTS_CPU_THREADS')
    if not settings.device.startswith('cuda'):
        raise ValueError('This service requires a CUDA GPU; TTS_DEVICE must be cuda:<index>')
    return settings


def validate_model(path):
    path = Path(path)
    required = ['config.json', 'tokenizer_config.json', 'vocab.json', 'merges.txt',
                'speech_tokenizer/config.json', 'speech_tokenizer/preprocessor_config.json']
    missing = [name for name in required if not (path / name).is_file()]
    for folder in (path, path / 'speech_tokenizer'):
        if (folder / 'model.safetensors').is_file():
            continue
        index = folder / 'model.safetensors.index.json'
        if not index.is_file():
            missing.append(str(folder / 'model.safetensors[.index.json]'))
            continue
        data = json.loads(index.read_text(encoding='utf-8'))
        for shard in set(data['weight_map'].values()):
            if not (folder / shard).is_file():
                missing.append(str(folder / shard))
    if missing:
        raise FileNotFoundError(f'Incomplete local model directory {path}: {missing}. '
                                'Mount the complete model folder, including speech_tokenizer/.')
