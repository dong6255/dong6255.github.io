"""CPU-only API contract tests. GPU integration is exercised by smoke_docker.py."""
import base64
import io
import json
import os
import tempfile
import threading
import unittest
import wave
from unittest.mock import patch
from pathlib import Path

import numpy as np
from fastapi.testclient import TestClient

temporary = tempfile.TemporaryDirectory()
os.environ['TTS_OUTPUT_DIR'] = temporary.name
os.environ['TTS_ENABLE_LEGACY_UI'] = '0'
from fast_app import create_app
from service_config import validate_model


class FakeTTS:
    def get_supported_languages(self):
        return ['Chinese', 'Auto', 'English']

    def get_supported_speakers(self):
        return ['serena']


class FakeEngine:
    def __init__(self):
        self.tts, self.lock = FakeTTS(), threading.Lock()
        self.diagnostics = {'model_device': 'cuda:0', 'model': 'fake-local-model'}
        self.last_profile = {}

    def full(self, *args):
        audio = np.array([0, .25, -.25, 0], dtype=np.float32)
        return audio, 24000, {'audio_seconds': len(audio) / 24000, 'total_seconds': .01}

    def stream(self, *args):
        audio, sr, profile = self.full()
        for chunk in (audio[:2], audio[2:]):
            yield {'event': 'audio', 'audio': chunk, 'sample_rate': sr}
        yield {'event': 'done', 'audio': audio, 'sample_rate': sr,
               'profile': {**profile, 'full_samples': len(audio)}}


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.engine = FakeEngine()
        self.client = TestClient(create_app(self.engine, FakeEngine()))

    def test_binary_wav_has_exact_samples_and_rate(self):
        response = self.client.post('/api/tts/wav', json={'text': '你好'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers['content-type'], 'audio/wav')
        with wave.open(io.BytesIO(response.content)) as wav:
            self.assertEqual((wav.getnchannels(), wav.getsampwidth(), wav.getframerate(), wav.getnframes()),
                             (1, 2, 24000, 4))

    def test_json_audio_download_and_filename_isolation(self):
        response = self.client.post('/api/tts', json={'text': '你好'}).json()
        self.assertEqual(self.client.get(response['audio_url']).status_code, 200)
        self.assertEqual(self.client.get('/audio/not-a-generated-file.wav').status_code, 404)

    def test_stream_has_ordered_pcm_chunks_and_final_file(self):
        response = self.client.post('/api/tts/stream', json={'text': '你好'})
        events = [json.loads(line) for line in response.text.splitlines()]
        self.assertEqual([e['event'] for e in events], ['audio', 'audio', 'done'])
        self.assertEqual([e['index'] for e in events[:-1]], [0, 1])
        pcm = b''.join(base64.b64decode(e['pcm']) for e in events[:-1])
        self.assertEqual(len(pcm), 4 * 2)
        self.assertEqual(events[0]['format'], 'pcm_s16le')
        self.assertEqual(events[0]['channels'], 1)
        self.assertEqual(self.client.get(events[-1]['audio_url']).status_code, 200)

    def test_validation_and_busy_are_explicit(self):
        for payload in ({'text': '  '}, {'text': '你好', 'speaker': 'missing'},
                        {'text': '你好', 'model': 'fast', 'instruct': '高兴'},
                        {'text': '你好', 'chunk_frames': 1}):
            self.assertEqual(self.client.post('/api/tts', json=payload).status_code, 422)
        with self.engine.lock:
            self.assertEqual(self.client.post('/api/tts/wav', json={'text': '你好'}).status_code, 429)

    def test_offline_docs_and_openapi(self):
        docs = self.client.get('/docs').text
        self.assertIn('/static/docs/swagger-ui-bundle.js', docs)
        self.assertNotIn('https://cdn.', docs)
        self.assertEqual(self.client.get('/static/docs/swagger-ui-bundle.js').status_code, 200)
        schema = self.client.get('/openapi.json').json()
        self.assertIn('audio/wav', schema['paths']['/api/tts/wav']['post']['responses']['200']['content'])
        self.assertIn('application/x-ndjson', schema['paths']['/api/tts/stream']['post']['responses']['200']['content'])
        self.assertEqual(self.client.get('/healthz').json()['status'], 'ok')

    def test_missing_shard_is_reported_before_loading_gpu(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            (root / 'speech_tokenizer').mkdir()
            for file in ['config.json', 'tokenizer_config.json', 'vocab.json', 'merges.txt',
                         'speech_tokenizer/config.json', 'speech_tokenizer/preprocessor_config.json',
                         'speech_tokenizer/model.safetensors']:
                (root / file).write_text('{}')
            (root / 'model.safetensors.index.json').write_text(
                json.dumps({'weight_map': {'a': 'missing-shard.safetensors'}}))
            with self.assertRaisesRegex(FileNotFoundError, 'missing-shard'):
                validate_model(root)

    def test_cors_only_allows_configured_frontend(self):
        with patch.dict(os.environ, {'TTS_CORS_ORIGINS': 'http://example.intra:8080'}):
            client = TestClient(create_app(FakeEngine()))
        headers = {'Origin': 'http://example.intra:8080', 'Access-Control-Request-Method': 'POST',
                   'Access-Control-Request-Headers': 'Content-Type'}
        response = client.options('/api/tts/wav', headers=headers)
        self.assertEqual(response.headers['access-control-allow-origin'], 'http://example.intra:8080')
        headers['Origin'] = 'http://unlisted.intra'
        self.assertEqual(client.options('/api/tts/wav', headers=headers).status_code, 400)


if __name__ == '__main__':
    unittest.main()
